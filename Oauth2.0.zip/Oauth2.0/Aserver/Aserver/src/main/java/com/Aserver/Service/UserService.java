package com.Aserver.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.Aserver.data.UserRepository;
import com.Aserver.model.User;
import com.Aserver.model.UserPrincipal;

public class UserService implements UserDetailsService {
	
	@Autowired
	UserRepository repo;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		User user = repo.findByUsername(username);
		return new UserPrincipal(user.getId(),user.getUsername(),user.getPassword(),user.getRole().toArray(new String[user.getRole().size()]));
	}

}
