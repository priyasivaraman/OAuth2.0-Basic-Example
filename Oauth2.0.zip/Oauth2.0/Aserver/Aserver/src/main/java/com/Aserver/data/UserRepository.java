package com.Aserver.data;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.Aserver.model.User;

public interface UserRepository extends MongoRepository<User, Long>  {
	
	User findByUsername(String username);

}
