package com.Rserver.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.token.RemoteTokenServices;

@Configuration
@EnableResourceServer
public class RserverConfig  extends ResourceServerConfigurerAdapter{
	
	@Override
	public void configure(HttpSecurity http) throws Exception {
		http
			.csrf().disable()
			.httpBasic().and()
			.authorizeRequests()
			.antMatchers("/user/**").hasAnyAuthority("user")
			.antMatchers("/admin/**").hasAnyAuthority("admin")
			.antMatchers("/**").permitAll()
			.anyRequest().authenticated();		
	}
      
	@Override
	public void configure(ResourceServerSecurityConfigurer resources) throws Exception {
		resources.tokenServices(tokenService());
	}
	
	@Primary
	@Bean
	public RemoteTokenServices tokenService(){
		RemoteTokenServices tokens = new RemoteTokenServices();		
		tokens.setCheckTokenEndpointUrl("http://localhost:8001/auth/oauth/check_token");
		tokens.setClientId("my-client-app");
		tokens.setClientSecret("password");
		return tokens;
	}
}

