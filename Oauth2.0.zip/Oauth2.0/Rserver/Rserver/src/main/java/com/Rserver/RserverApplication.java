package com.Rserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(RserverApplication.class, args);
	}
}
